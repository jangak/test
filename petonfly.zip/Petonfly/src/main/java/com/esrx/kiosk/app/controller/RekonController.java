package com.esrx.kiosk.app.controller;


import com.esrx.kiosk.app.model.Prescription;
import com.esrx.kiosk.app.service.AmazonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/rekon/")
public class RekonController {

    private AmazonClient amazonClient;

    @Autowired
    RekonController(AmazonClient amazonClient) {
        this.amazonClient = amazonClient;
    }

    @GetMapping("/detectText")
    public Prescription detectText(@RequestPart(value = "String") String fileName) {
       // return this.amazonClient.rekon(fileName);
        return null;
    }
}
