package com.esrx.kiosk.app.service;

import com.amazonaws.services.rekognition.model.TextDetection;
import com.esrx.kiosk.app.model.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.regex.Pattern;
import java.io.*;
import java.net.*;
import javax.net.ssl.HttpsURLConnection;

public class RekonService {

    static String host = "https://api.cognitive.microsoft.com";
    static String path = "/bing/v7.0/spellcheck";
    static String key = "4126d1a377d94fe589ff5eaec6a39bb5";
    static String endpoint = "https://api.cognitive.microsoft.com/bing/v7.0/spellcheck";

    static String mkt = "en-US";
    static String mode = "proof";


    public RekonService() {

    }

    public List<ReconDetection>  getDetections(List<TextDetection> detections) {
        List <ReconDetection> reconDetections = new ArrayList<>();
        ReconDetection reconDetection;
        Practitioner practitioner = new Practitioner();
        Drug drug = new Drug();
        Prescription prescription = new Prescription();
        Member patient = new Member();
        StringBuffer tmpName = new StringBuffer();

        for (TextDetection text: detections) {
             reconDetection = new ReconDetection();
            if (text.getType().matches("LINE")) {


                if (text.getDetectedText() != null) {
                    String name = text.getDetectedText().toUpperCase();
                 //   String[] spells = validateSpelling(name);


                    if (name.contains("M.D") || (name.contains("HOSPITAL")) || (name.contains("MD"))) {
                        practitioner.setName(name);
                    } else if (name.contains("NPI") || (name.contains("DEA"))) {
                        practitioner.setNpi(name);
                    } else if (name.contains("Ph") || (name.contains("PHONE"))) {
                        practitioner.setPhoneNumber(name);
                    }  else if (name.contains("FAX") ) {
                        practitioner.setFaxNumber(name);
                    } else if (name.contains("PATIENT NAME") ) {

                       /* StringTokenizer st = new StringTokenizer(name);
                        while (st.hasMoreElements()) {
                            String token = st.nextElement().toString();
                            if (token.contains("PATIENT")|| (token.contains("NAME")) ||
                                    (token.contains("DATE"))|| (token.contains("PRESCRIBED"))) {
                                System.out.println ("ignore these words");
                            }else {
                                tmpName = tmpName.append(" " +token);
                                patient.setName(token);
                            }
                        }*/

                       String[] tokens = name.split(" ");
                       patient.setName(tokens[1] + " " + tokens[2]);

                    } else if (name.contains("BIRTH")) {
                        StringTokenizer st = new StringTokenizer(name);
                        while (st.hasMoreElements()) {
                           String tn = st.nextElement().toString();
                            if (tn.contains("O")) {
                                tn.replace("O", "0");
                            }
                          //  Scanner sc = new Scanner(tn).useDelimiter("[^0-9]+");
                          //  Scanner sc = new Scanner(tn).useDelimiter("[^0-9]+");
                            patient.setDob(name);
                        }

                    } else if (name.contains("MG") ||
                            (name.contains("GRAM")) ||
                            (name.contains("LOTION"))||
                            (name.contains("ML"))) {

                     //   Scanner sc = new Scanner(name).useDelimiter("[^0-9]+");
                     //   drug.setStrength(String.valueOf(sc.nextInt()));
                        drug.setName(name);
                    } else if (name.contains("QTY") || (name.contains("ETY"))|| (name.contains("QUANTITY"))) {
                        prescription.setQty(name);
                    }

                }

                    reconDetection.setDetectedText(text.getDetectedText());
                    reconDetection.setConfidence(text.getConfidence().toString());
                    reconDetection.setId(text.getId());
                    reconDetection.setParentId(text.getParentId());
                    reconDetection.setType(text.getType());

                    System.out.println("Detected: " + text.getDetectedText());
                    System.out.println("Confidence: " + text.getConfidence().toString());
                    System.out.println("Id : " + text.getId());
                    System.out.println("Parent Id: " + text.getParentId());
                    System.out.println("Type: " + text.getType());
                    System.out.println("----");
                }

                reconDetections.add(reconDetection);
                }

                prescription.setMember(patient);
                prescription.setPractitioner(practitioner);
                prescription.setDrug(drug);
                System.out.println("Prescription " + prescription.toString());

        return reconDetections;

        }

    private String[] validateSpelling(String line) {

        try {
            String params = "?mkt=" + mkt + "&mode=" + mode;


            URL url = new URL( endpoint + params);
            HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            connection.setRequestProperty("Content-Length", "" + line.length() + 5);
            connection.setRequestProperty("Ocp-Apim-Subscription-Key", key);
            connection.setDoOutput(true);

            DataOutputStream wr = new DataOutputStream(connection.getOutputStream());
            wr.writeBytes("text=" + line);
            wr.flush();
            wr.close();

            BufferedReader in = new BufferedReader(
                    new InputStreamReader(connection.getInputStream()));
            String liner;
            while ((liner = in.readLine()) != null) {
                System.out.println(line);
            }
            in.close();




        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }


}
