package com.esrx.kiosk.app.model;

public class Practitioner {

    private String npi;
    private String dea;
    private String name;
    private Address address;
    private String phoneNumber;

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public String getFaxNumber() {
        return faxNumber;
    }

    public void setFaxNumber(String faxNumber) {
        this.faxNumber = faxNumber;
    }

    private String faxNumber;

    @Override
    public String toString() {
        return "Practitioner{" +
                "npi='" + npi + '\'' +
                ", dea='" + dea + '\'' +
                ", name='" + name + '\'' +

                ", phoneNumber='" + phoneNumber + '\'' +
                '}';
    }

    public String getNpi() {
        return npi;
    }

    public void setNpi(String npi) {
        this.npi = npi;
    }

    public String getDea() {
        return dea;
    }

    public void setDea(String dea) {
        this.dea = dea;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }


}
