package com.esrx.kiosk.app.service;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.rekognition.model.S3Object;
import com.esrx.kiosk.app.model.Prescription;
import com.esrx.kiosk.app.model.ReconDetection;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.amazonaws.services.rekognition.model.AmazonRekognitionException;
import com.amazonaws.services.rekognition.AmazonRekognition;
import com.amazonaws.services.rekognition.AmazonRekognitionClientBuilder;
import com.amazonaws.services.rekognition.model.DetectTextRequest;
import com.amazonaws.services.rekognition.model.DetectTextResult;

import com.amazonaws.services.rekognition.model.TextDetection;
import com.amazonaws.services.rekognition.model.Image;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.net.ssl.HttpsURLConnection;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.stream.Collectors;

@Service
public class AmazonClient {

    private AmazonS3 s3client;
    private AmazonRekognition reconClient;

    @Value("${amazonProperties.endpointUrl}")
    private String endpointUrl;
    @Value("${amazonProperties.bucketName}")
    private String bucketName;
    @Value("${amazonProperties.accessKey}")
    private String accessKey;
    @Value("${amazonProperties.secretKey}")
    private String secretKey;

    @PostConstruct
    private void initializeAmazon() {
        BasicAWSCredentials credentials = new BasicAWSCredentials(this.accessKey, this.secretKey);
        s3client = AmazonS3ClientBuilder.standard()
                .withRegion(Regions.US_EAST_2)
                .withCredentials(new AWSStaticCredentialsProvider(credentials))
                .build();
        System.out.println("s3client:" + s3client.getRegionName());

        reconClient = AmazonRekognitionClientBuilder
                .standard()
                .withRegion(Regions.US_EAST_2)
                .withCredentials(new AWSStaticCredentialsProvider(credentials))
                .build();


    }

    public String uploadFile(MultipartFile multipartFile) {
        String fileUrl = "";
        try {
            File file = convertMultiPartToFile(multipartFile);
            String fileName = generateFileName(multipartFile);
            fileUrl = endpointUrl + "/" + bucketName + "/" + fileName;
            uploadFileTos3bucket(fileName, file);
            file.delete();
            System.out.println("successfully uploaded image to kiosk bucket");
            Prescription prescription = detectText(fileName);
        } catch (Exception e) {
           e.printStackTrace();
        }
        return fileUrl;
    }

    private File convertMultiPartToFile(MultipartFile file) throws IOException {
        File convFile = new File(file.getOriginalFilename());
        FileOutputStream fos = new FileOutputStream(convFile);
        fos.write(file.getBytes());
        fos.close();
        return convFile;
    }

    private String generateFileName(MultipartFile multiPart) {
        return new Date().getTime() + "-" + multiPart.getOriginalFilename().replace(" ", "_");
    }

    private void uploadFileTos3bucket(String fileName, File file) {
        System.out.println("bucketName" + bucketName);
        System.out.println("File Name" + fileName);
        System.out.println("File" + file);

        s3client.putObject(new PutObjectRequest(bucketName, fileName, file)
               .withCannedAcl(CannedAccessControlList.PublicRead));

    }

    public String deleteFileFromS3Bucket(String fileUrl) {
        String fileName = fileUrl.substring(fileUrl.lastIndexOf("/") + 1);
        s3client.deleteObject(new DeleteObjectRequest(bucketName, fileName));
        return "Successfully deleted";
    }

    public Prescription detectText(String fileName) {
        Prescription pr = new Prescription();

        RekonService reconService = new RekonService();

        DetectTextRequest request = new DetectTextRequest()
                .withImage(new Image()
                        .withS3Object(new S3Object()
                                .withName(fileName)
                                .withBucket(bucketName)));

        try {
            DetectTextResult result = reconClient.detectText(request);
            List<TextDetection> textDetections = result.getTextDetections();
            List <ReconDetection> reconDetections = reconService.getDetections(textDetections);

         /*   List<ReconDetection> npidetectors = reconDetections.stream().filter(tmpdetections -> (tmpdetections.getDetectedText()
                    .contains("NPI") || tmpdetections.getDetectedText().contains("DEA"))).
                    collect(Collectors.toCollection(() -> new ArrayList<ReconDetection>()));



            for (ReconDetection npi: npidetectors) {
                    System.out.println(npi.getDetectedText());
            }

*/


           /* System.out.println("Detected lines and words for " + fileName);
            for (TextDetection text: textDetections) {

                System.out.println("Detected: " + text.getDetectedText());
                System.out.println("Confidence: " + text.getConfidence().toString());
                System.out.println("Id : " + text.getId());
                System.out.println("Parent Id: " + text.getParentId());
                System.out.println("Type: " + text.getType());
                System.out.println();
            }*/
        } catch(AmazonRekognitionException e) {
            e.printStackTrace();
        }

        return pr;
    }
}
