package com.esrx.kiosk.app.model;
import java.util.List;

public class Prescription {

    private Member member;
    private Practitioner practitioner;
    private Drug drug;
    private String daysSupply;
    private String qty;
    private String directions;
    private List<String> allergies;

    @Override
    public String toString() {
        return "Prescription{" +
                "member=" + member +
                ", practitioner=" + practitioner +
                ", drug=" + drug +
                ", daysSupply='" + daysSupply + '\'' +
                ", qty='" + qty + '\'' +
                '}';
    }

    public Member getMember() {
        return member;
    }

    public void setMember(Member member) {
        this.member = member;
    }

    public Practitioner getPractitioner() {
        return practitioner;
    }

    public void setPractitioner(Practitioner practitioner) {
        this.practitioner = practitioner;
    }

    public Drug getDrug() {
        return drug;
    }

    public void setDrug(Drug drug) {
        this.drug = drug;
    }

    public String getDaysSupply() {
        return daysSupply;
    }

    public void setDaysSupply(String daysSupply) {
        this.daysSupply = daysSupply;
    }

    public String getQty() {
        return qty;
    }

    public void setQty(String qty) {
        this.qty = qty;
    }

    public String getDirections() {
        return directions;
    }

    public void setDirections(String directions) {
        this.directions = directions;
    }

    public List<String> getAllergies() {
        return allergies;
    }

    public void setAllergies(List<String> allergies) {
        this.allergies = allergies;
    }
}

