package com.esrx.kiosk.app.model;

public class Drug {

    private String ndc;
    private String name;
    private String strength;

    public String getNdc() {
        return ndc;
    }

    public void setNdc(String ndc) {
        this.ndc = ndc;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStrength() {
        return strength;
    }

    public void setStrength(String strength) {
        this.strength = strength;
    }

    @Override
    public String toString() {
        return "Drug{" +
                "ndc='" + ndc + '\'' +
                ", name='" + name + '\'' +
                ", strength='" + strength + '\'' +
                '}';
    }
}
